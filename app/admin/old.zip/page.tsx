import prisma from '@/lib/prisma';
import Link from 'next/link';
import DeleteTourButton from '@/components/DeleteTourButton';
import { deleteTour } from './add-tour/actions';
import BookingModeDropdown from '@/components/BookingModeDropdown';
import { UserButton } from "@clerk/nextjs";
import { auth } from '@clerk/nextjs/server';
import React from 'react';

export default async function AdminDashboard() {
  const { userId } = await auth();

  if (!userId) return null;

  // 1. Fetch the tenant data to get the custom colors
  const tenant = await prisma.tenant.findUnique({
    where: { userId: userId }
  });

  if (!tenant) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
        <h2 className="text-xl font-bold text-gray-800">Configuration Required</h2>
        <p className="text-gray-500 mt-2">Please configure your agency settings first.</p>
        <Link href="/admin/settings" className="mt-4 inline-block bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium">
          Go to Settings
        </Link>
      </div>
    </div>
  );

  // 2. Fetch the tours
  const tours = await prisma.tour.findMany({
    where: {
      tenant: { userId: userId }
    },
    orderBy: { createdAt: 'desc' }
  });

  // 3. Map database colors to global CSS variables
  const globalTheme = {
    '--theme-primary': tenant.primaryColor || '#003580',
    '--theme-accent': tenant.accentColor || '#FF8C00',
    '--theme-navbar': tenant.navbarColor || '#003580',
    '--theme-button': tenant.buttonColor || '#FF8C00',
    '--theme-heading': tenant.headingColor || '#1F2937',
    '--theme-footer': tenant.footerColor || '#111827', 
    '--theme-card': tenant.cardColor || '#111827', 
    '--navlink': tenant.navlink || '#111827', 
    '--axius-primary': tenant.primaryColor || '#003580',
    '--axius-secondary': tenant.headingColor || '#1F2937',
    fontFamily: 'var(--font-poppins, sans-serif)',
  } as React.CSSProperties;

  return (
    <div style={globalTheme} className="flex h-screen bg-gray-50 overflow-hidden text-[var(--axius-secondary)]">
      
      {/* 4. COLLAPSIBLE SIDEBAR (CSS Hover Driven) */}
      <aside className="w-[80px] hover:w-[260px] group transition-all duration-300 ease-in-out border-r border-gray-200 flex flex-col shadow-2xl relative z-50 overflow-hidden" style={{backgroundColor:"#1e293e"}}>
        
        {/* Brand Logo Area */}
        <div className="h-20 flex items-center px-6 border-b border-gray-100 min-w-[260px]">
          <div className="w-8 h-8 rounded-lg bg-[var(--theme-primary)] flex items-center justify-center text-white font-black text-xl shadow-md shrink-0">
            T
          </div>
          <span className="ml-4 font-black text-xl tracking-wide opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            Travelo
          </span>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 py-6 px-4 space-y-2 flex flex-col min-w-[260px]">
          {/* Active Dashboard Link */}
          <Link href="/admin" className="flex items-center px-3 py-3.5 bg-[var(--theme-primary)] text-white rounded-xl shadow-md shadow-blue-500/20 group/link">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" className="w-5 h-5 shrink-0 ml-0.5"><path fill="currentColor" d="M64 144a48 48 0 1 0 0-96 48 48 0 1 0 0 96zM192 64c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L192 64zm0 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-288 0zm0 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-288 0zM64 464a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm48-208a48 48 0 1 0 -96 0 48 48 0 1 0 96 0z"/></svg>
            <span className="ml-5 font-semibold text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300">Dashboard</span>
          </Link>

          <Link href="/admin/leads" className="flex items-center px-3 py-3.5 text-gray-500 hover:text-[var(--theme-primary)] hover:bg-blue-50 rounded-xl transition-colors group/link">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" className="w-5 h-5 shrink-0 ml-0.5"><path fill="currentColor" d="M28.4 86.9C32.9 55.4 59.9 32 91.8 32l328.5 0c31.8 0 58.9 23.4 63.4 54.9l27.8 194.3c.4 3 .6 6 .6 9.1L512 416c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 290.3c0-3 .2-6.1 .6-9.1L28.4 86.9zM420.2 96l-328.5 0-27.4 192 59.9 0c12.1 0 23.2 6.8 28.6 17.7l14.3 28.6c5.4 10.8 16.5 17.7 28.6 17.7l120.4 0c12.1 0 23.2-6.8 28.6-17.7l14.3-28.6c5.4-10.8 16.5-17.7 28.6-17.7l59.9 0-27.4-192zM152 128l208 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-208 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm0 80l208 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-208 0c-13.3 0-24-10.7-24-24s10.7-24 24-24z"/></svg>
            <span className="ml-5 font-semibold text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300">View Leads</span>
          </Link>

          <Link href="/admin/settings" className="flex items-center px-3 py-3.5 text-gray-500 hover:text-[var(--theme-primary)] hover:bg-blue-50 rounded-xl transition-colors group/link">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" className="w-5 h-5 shrink-0 ml-0.5"><path fill="currentColor" d="M195.1 9.5C198.1-5.3 211.2-16 226.4-16l59.8 0c15.2 0 28.3 10.7 31.3 25.5L332 79.5c14.1 6 27.3 13.7 39.3 22.8l67.8-22.5c14.4-4.8 30.2 1.2 37.8 14.4l29.9 51.8c7.6 13.2 4.9 29.8-6.5 39.9L447 233.3c.9 7.4 1.3 15 1.3 22.7s-.5 15.3-1.3 22.7l53.4 47.5c11.4 10.1 14 26.8 6.5 39.9l-29.9 51.8c-7.6 13.1-23.4 19.2-37.8 14.4l-67.8-22.5c-12.1 9.1-25.3 16.7-39.3 22.8l-14.4 69.9c-3.1 14.9-16.2 25.5-31.3 25.5l-59.8 0c-15.2 0-28.3-10.7-31.3-25.5l-14.4-69.9c-14.1-6-27.2-13.7-39.3-22.8L73.5 432.3c-14.4 4.8-30.2-1.2-37.8-14.4L5.8 366.1c-7.6-13.2-4.9-29.8 6.5-39.9l53.4-47.5c-.9-7.4-1.3-15-1.3-22.7s.5-15.3 1.3-22.7L12.3 185.8c-11.4-10.1-14-26.8-6.5-39.9L35.7 94.1c7.6-13.2 23.4-19.2 37.8-14.4l67.8 22.5c12.1-9.1 25.3-16.7 39.3-22.8L195.1 9.5zM256.3 336a80 80 0 1 0 -.6-160 80 80 0 1 0 .6 160z"/></svg>
            <span className="ml-5 font-semibold text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300">Settings</span>
          </Link>
          
          <div className="pt-4 mt-2 border-t border-gray-100">
            <Link href="/admin/add-tour" className="flex items-center px-3 py-3.5 bg-[#4389f7]/10 text-[#4389f7] hover:bg-[#4389f7] hover:text-white rounded-xl transition-all group/link">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" className="w-5 h-5 shrink-0 ml-0.5"><path fill="currentColor" d="M256 64c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 160-160 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l160 0 0 160c0 17.7 14.3 32 32 32s32-14.3 32-32l0-160 160 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-160 0 0-160z"/></svg>
              <span className="ml-5 font-bold text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300">Add New Tour</span>
            </Link>
          </div>
        </nav>

        {/* User Profile Area */}
        <div className="p-4 border-t border-gray-100 min-w-[260px] flex items-center bg-gray-50/50">
          <div className="shrink-0 ml-1">
            <UserButton 
              afterSignOutUrl="/" 
              appearance={{
                elements: {
                  avatarBox: "w-9 h-9 border-2 border-[var(--theme-primary)] shadow-sm",
                  userButtonTrigger: "rounded-full focus:ring-2 focus:ring-[var(--theme-primary)] focus:ring-offset-2 outline-none transition-all",
                }
              }}
            />
          </div>
          <div className="ml-4 flex flex-col opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <span className="text-sm font-bold text-gray-800">My Account</span>
            <span className="text-xs text-gray-500 font-medium">Agency Admin</span>
          </div>
        </div>
      </aside>

      {/* 5. MAIN CONTENT AREA */}
      <main 
        style={{
          backgroundImage: `linear-gradient(rgba(17, 24, 39, 0.75), rgba(17, 24, 39, 0.85)), url('/assets/images/Background.jpg')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
        }} 
        className="flex-1 h-screen overflow-y-auto relative"
      >
        <div className="max-w-6xl mx-auto p-8 space-y-8 min-h-full flex flex-col">
          
          {/* Main Dashboard Header */}
          <header className="flex flex-col gap-2 pt-4">
            <h1 className="text-3xl font-black text-white tracking-tight">
              Agency Dashboard
            </h1>
            <p className="text-gray-300 font-medium text-sm">
              Manage your listings, monitor active tours, and configure booking options.
            </p>
          </header>

          {/* Manage Tours Table Card */}
          <div className="bg-white rounded-2xl shadow-xl shadow-black/20 overflow-hidden flex-1 border border-gray-100/50">
            <div className="px-6 py-5 border-b border-gray-100 flex justify-between items-center bg-white">
              <div className="flex items-center gap-3">
                <h2 className="text-lg font-bold text-[var(--axius-secondary)]">Active Listings</h2>
                <span className="bg-blue-50 text-[var(--axius-primary)] text-xs font-bold px-2.5 py-1 rounded-full">
                  {tours.length} Total
                </span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[800px]">
                <thead className="bg-gray-50/80 border-b border-gray-200 text-xs uppercase tracking-wider text-gray-500 font-semibold">
                  <tr>
                    <th className="px-6 py-4">Tour Details</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Booking Option</th>
                    <th className="px-6 py-4">Price</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                {tours.map((tour: any) => (
                    <tr key={tour.id} className="hover:bg-gray-50/60 transition-colors group">
                      <td className="px-6 py-4">
                        <p className="font-semibold text-[var(--axius-secondary)] text-base mb-0.5 group-hover:text-[var(--axius-primary)] transition-colors">
                          {tour.title}
                        </p>
                        <p className="text-xs text-gray-500 font-medium">
                          {tour.destination} <span className="mx-1 text-gray-300">•</span> {tour.duration}
                        </p>
                      </td>
                      <td className="px-6 py-4">
                        {tour.status === 'ACTIVE' ? (
                          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-green-50 text-green-700 border border-green-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-green-600 mr-1.5"></span>
                            Active
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-600 border border-gray-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-gray-400 mr-1.5"></span>
                            Draft
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="w-36">
                          <BookingModeDropdown
                            tourId={tour.id}
                            currentMode={tour.bookingMode || 'BOTH'}
                          />
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-semibold text-[var(--axius-secondary)]">
                          Rs. {tour.basePrice.toLocaleString()}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex justify-end gap-2">
                          <Link
                            href={`/admin/edit-tour/${tour.id}`}
                            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                            title="Edit Tour"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" className="w-4 h-4">
                              <path fill="currentColor" d="M471.6 21.7c-21.9-21.9-57.3-21.9-79.2 0L368 46.1 465.9 144 490.3 119.6c21.9-21.9 21.9-57.3 0-79.2L471.6 21.7zm-299.2 220c-6.1 6.1-10.8 13.6-13.5 21.9l-29.6 88.8c-2.9 8.6-.6 18.1 5.8 24.6s15.9 8.7 24.6 5.8l88.8-29.6c8.2-2.7 15.7-7.4 21.9-13.5L432 177.9 334.1 80 172.4 241.7zM96 64C43 64 0 107 0 160L0 416c0 53 43 96 96 96l256 0c53 0 96-43 96-96l0-96c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 96c0 17.7-14.3 32-32 32L96 448c-17.7 0-32-14.3-32-32l0-256c0-17.7 14.3-32 32-32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L96 64z"/>
                            </svg>
                          </Link>
                          {/* Delete Form with Server Action */}
                          <div className="text-gray-400 hover:text-red-600 transition-colors">
                            <DeleteTourButton tourId={tour.id} />
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {tours.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 px-4">
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                  </svg>
                </div>
                <p className="text-gray-500 font-medium">Your database is currently empty.</p>
                <p className="text-gray-400 text-sm mt-1">Start by adding your first tour listing.</p>
              </div>
            )}
          </div>

          {/* Footer inside main content */}
          <div className="mt-auto pt-6">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl py-4 px-6 shadow-lg flex items-center justify-center">
              <p className="text-sm text-gray-300 font-medium">
                Copyright © {new Date().getFullYear()} Travelo TMS. All Rights Reserved. A product by <span className="text-white font-semibold">Axius Digital</span>
              </p>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}